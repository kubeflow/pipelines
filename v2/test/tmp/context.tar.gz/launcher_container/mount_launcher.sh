#!/bin/sh

cp /bin/launch /kfp-launcher/launch