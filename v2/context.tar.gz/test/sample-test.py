# %%
HOST = 'https://71a74112589c16e8-dot-asia-east1.pipelines.googleusercontent.com'

# %%
import kfp
import kfp.components as comp


def fail():
    import sys
    println("failed")
    sys.exit(1)


def echo():
    println("hello world")


fail_op = comp.func_to_container_op(fail)
echo_op = comp.func_to_container_op(echo)

# steps
# 1. build kfp-launcher container
# 2. run v2 experimental pipelines using newly built kfp-launcher
# 3. verify pipeline results in MLMD and GCS

kaniko = kfp.components.load_component_from_text(
    '''
name: Kaniko
inputs:
- {name: dockerfile, type: String}
- {name: context, type: String}
- {name: destination, type: String}
# outputs:
# - {name: built-image-uri, type: String}
metadata:
  annotations:
    author: Yuan Gong <gongyuan94@gmail.com>
implementation:
  container:
    image: gcr.io/kaniko-project/executor:latest
    command:
    - /kaniko/executor
    - --dockerfile
    - inputValue: dockerfile
    - --context
    - inputValue: context
    - --destination
    - inputValue: destination
    - --digest-file=/dev/termination-log
'''
)


@kfp.dsl.pipeline(name='v2 sample test')
def v2_sample_test(context: str):
    kaniko(
        context=context,
        destination='gcr.io/gongyuan-pipeline-test/kfp-launcher:latest',
        dockerfile='launcher_container/Dockerfile'
    )


# %%
def main():
    client = kfp.Client(host=HOST)
    client.create_run_from_pipeline_func(fail_sample, {})


if __name__ == "__main__":
    main()
