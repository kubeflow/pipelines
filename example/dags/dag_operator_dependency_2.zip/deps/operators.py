import logging

from airflow.models import BaseOperator
from airflow.plugins_manager import AirflowPlugin
from airflow.utils.decorators import apply_defaults
from datetime import datetime, timedelta

log = logging.getLogger(__name__)

class MyFirstOperator(BaseOperator):

    @apply_defaults
    def __init__(self, *args, **kwargs):
        super(MyFirstOperator, self).__init__(*args, **kwargs)

    def execute(self, context):
        with open("/root/airflow/python_output.txt", "a") as fh:
	        fh.write("From Second operators")
    	return 1


class MyFirstPlugin(AirflowPlugin):
    name = "my_first_plugin"
    operators = [MyFirstOperator]
